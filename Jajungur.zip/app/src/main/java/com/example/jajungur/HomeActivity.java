package com.example.jajungur;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setTitle("자전거");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.homemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.MyPage:
                Intent MyIntent = new Intent(getApplicationContext(), MyPageActivity.class); //마이페이지 화면 이동
                startActivity(MyIntent);//마이페이지 화면 이동
                return true;

            case R.id.Community:
                Intent CommuIntent = new Intent(getApplicationContext(), Community.class); //커뮤니티 화면 이동
                startActivity(CommuIntent);//커뮤니티 화면 이동
                return true;

            case R.id.Customer:
                Intent CusIntent = new Intent(getApplicationContext(), Customer.class); //고객지원 화면 이동
                startActivity(CusIntent);//고객지원 화면 이동
                return true;
        }
        return false;
    }
}

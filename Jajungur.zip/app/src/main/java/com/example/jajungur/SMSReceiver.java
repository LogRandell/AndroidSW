package com.example.jajungur;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.lang.Object;


public class SMSReceiver extends BroadCastReceiver{

    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    private static final String TAG = "SmsReceiver";
    private static SimpleDateFormat format = new SimpleDateFormat("yyyy 년 MM 월 dd 일 / HH 시 mm분");
    @Override
    public void onReceive(Context context, Intent intent) {

        //sms_received에 대한 액션일 때
        if(intent.getAction()
                .equals(SMS_RECEIVED)) {
            Log.d(TAG, "온리시버를 호출합니다.");
            //번들을 이용하여 메세지 내용을 가져옴

            Bundle bundle = intent.getExtras();
            SmsMessage[] messages = parseSmsMessage(bundle);
            //메세지가 있을 경우 내용을 출력한다.
            if(messages.length > 0) {
                //메세지의 내용을 가져옴
                //결제 후 적용가능
                String sender = messages[0].getOriginatingAddress();
                String contents = messages[0].getMessageBody().toString();
                Date receivedDate = new Date(messages[0].getTimestampMillis());

                // 로그의 내용을 디버깅하는 코드, 디버깅시 활성화함

                /*
                Log.d(TAG, "Sender :" + sender);
                Log.d(TAG, "contents : " + contents);
                Log.d(TAG, "receivedDate : " + receivedDate);
                */

                //액티비티로 값을 전달한다.
                sendToActivity(context, sender, contents, receivedDate);
            }
        }
    }
    // 위 액티비티로 메세지의 내용을 전달해주는 매소드
    private void sendToActivity(Context context, String sender, String contents, Date receivedDate) {
        Intent intent = new Intent(context, SmsActivity.class);
    //Flag 를 설정한다. 새로운 테스크를 만들며 그 안에 액티비티를 추가한다.  FLAG_ACTIVITY_RESET_TASK_IF_NEEDED 의 경우 호출해도 액티비티가 실행 되지 않을 수 있으니 참고하여 사용한다
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        //메세지 내용을 Extra 에 넣어준다.

        intent.putExtra("sender", sender);
        intent.putExtra("contents", contents);
        intent.putExtra("receivedDate", format.format(receivedDate));
        context.startActivity(intent);
    }

    private SmsMessage[] parseSmsMessage(Bundle bundle) {
        //bundle 안에는 "pdus"라는 key 값으로 SMS 정보가 들어가 있다.
        Object[] objs = (Object[]) bundle.get("pdus");
        SmsMessage[] messages = new SmsMessage[objs.length];
        for(int i = 0; i < objs.length; i++) {
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                String format = bundle.getString("format");
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i], format);
            } else {

                //에러 확인 코드로 수정정
               System.out.println("error");

               // messages[i] = SmsMessage.createFromPdu((byte[]) objs[i]);
            }
        }
        return messages;
    }


}
//참고 api https://developer.android.com/reference/android/content/BroadcastReceiver

